//1
int bitNor(int, int);
int test_bitNor(int, int);
int tmax();
int test_tmax();
//2
int implication(int, int);
int test_implication(int, int);
int divpwr2(int, int);
int test_divpwr2(int, int);
int isNegative(int);
int test_isNegative(int);
//3
int conditional(int, int, int);
int test_conditional(int, int, int);
int rotateRight(int, int);
int test_rotateRight(int, int);
//4
int absVal(int);
int test_absVal(int);
int bang(int);
int test_bang(int);
int greatestBitPos(int);
int test_greatestBitPos(int);
//float
unsigned float_abs(unsigned);
unsigned test_float_abs(unsigned);
unsigned float_pwr2(int);
unsigned test_float_pwr2(int);
unsigned float_i2f(int);
unsigned test_float_i2f(int);
